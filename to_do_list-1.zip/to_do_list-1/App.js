import { Text, View } from 'react-native';
import List from './components/List';

//slider(중요도에 따른 순서 배치), checkbox, date를 사용하여 마감일시 넣기

export default function App() {
  return <List />;
}
