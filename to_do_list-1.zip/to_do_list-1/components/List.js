import { Text, View, TextInput, Button, StyleSheet} from 'react-native';
import { useState } from 'react';

import ListPrint from './ListPrint';

const List = () => {
  const [textInput, setTextInput] = useState('');
  const [doList, setDoList] = useState([]);

  const onAddTextToList = () => {
    setDoList([...doList, textInput]);
    setTextInput("")
  };
  return (
    <View style = {styles.container}>
      <Text style = {styles.textCon}> 할 일을 작성하십시오. </Text>
      <TextInput style = {styles.tIContainer}
        value={textInput}
        onChangeText={setTextInput}
      />

      <Button 
        style = {styles.buttonCon}
        title="추가"
        onPress={(onAddTextToList)} 
      />
      <ListPrint doList={doList} />
    </View>
  );
};

const styles = StyleSheet.create({
  container:{
    padding:10


  },
  textCon:{
    backgroundColor: "#cecece",
    textAlign:"center",
    fontSize: 15,
    justifyContent: 'space-between',
    height: 25
  },
  tIContainer:{
    padding: 10,
    justifyContent: 'space-between',
    fontSize: 20, 
    backgroundColor: "#ceceff"

  },
  buttonCon:{
    fontColor: "red",
    backgroundColor: "#fcfccf"
  }
})


export default List;
