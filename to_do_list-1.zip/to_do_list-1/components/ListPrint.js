import {View, Text, CheckBox, StyleSheet} from "react-native"
import {useState} from "react"

const ListPrint = (props) =>{

  const [selected,setSelected] = useState([false]);
  
  return(
    <View >
      <Text> asd </Text>
      {props.doList.map((item, index)=>{
        return(
          <View style = {styles.container}>
            <Text style = {styles.printContainer}>
              No.{index + 1}  :  {item}
              <CheckBox
                value={selected}
                onValueChange={setSelected}
                style = {styles.checkBoxContainer}
              />  
            </Text>

          </View>
        )
      })}
    </View>
  )
}

const styles = StyleSheet.create({
  container:{
    flex: 1,
    
    backgroundColor: "#cccfff",
  },
  printContainer: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: "#cccccc",
    
  },
  checkBoxContainer:{
    width:20,
    height:20,

    alignItem: "left",
    justifyContent: "flex-end"
  }
})

export default ListPrint;